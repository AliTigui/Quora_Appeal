## Auto appeal extension
Browser extension to automate appeal for Quora answers

## Installing extension
### For Google Chrome
First clone this repo or download and unzip it then open Google Chrome go to extension click manage extension, activate developer mode then click load unpacked
![Chrome tutorial](chrome.gif)
### For Microsoft Edge
First clone this repo or download and unzip it then open Google Chrome go to extension click manage extension, activate developer mode then click load unpacked extension

![Edge tutorial](edge.gif)
